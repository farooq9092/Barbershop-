// ============================================
// data.js — Barber & Service Data
// ============================================

const BARBERS = [
  {
    id: 1,
    name: "Ustad Aslam",
    emoji: "💈",
    specialty: "Classic Cuts & Hot Shave",
    status: "available", // available | busy | break
    currentClient: null,
    currentServiceEnd: null,
    totalDone: 0,
    queue: [],
  },
  {
    id: 2,
    name: "Bilal Khan",
    emoji: "✂️",
    specialty: "Modern & Fade Styles",
    status: "available",
    currentClient: null,
    currentServiceEnd: null,
    totalDone: 0,
    queue: [],
  },
  {
    id: 3,
    name: "Hamza Bhai",
    emoji: "🪒",
    specialty: "Beard & Color Specialist",
    status: "available",
    currentClient: null,
    currentServiceEnd: null,
    totalDone: 0,
    queue: [],
  },
  {
    id: 4,
    name: "Tariq Ustad",
    emoji: "👑",
    specialty: "Hair Treatments & Styling",
    status: "available",
    currentClient: null,
    currentServiceEnd: null,
    totalDone: 0,
    queue: [],
  }
];

const SERVICES = {
  haircut:  { label: "Haircut",      duration: 20, price: 200 },
  beard:    { label: "Beard Trim",   duration: 15, price: 100 },
  shave:    { label: "Hot Shave",    duration: 25, price: 150 },
  full:     { label: "Full Service", duration: 40, price: 400 },
  color:    { label: "Hair Color",   duration: 60, price: 800 },
};

// Appointments stored in memory (localStorage for persistence)
let appointments = JSON.parse(localStorage.getItem('rc_appointments') || '[]');

// Save appointments to localStorage
function saveAppointments() {
  localStorage.setItem('rc_appointments', JSON.stringify(appointments));
}

// Generate unique ID
function genId() {
  return 'apt_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
}

// Format time HH:MM
function formatTime(date) {
  if (!date) return '--:--';
  const d = new Date(date);
  return d.toTimeString().slice(0, 5);
}

// Format countdown (minutes and seconds)
function formatCountdown(ms) {
  if (ms <= 0) return '00:00';
  const totalSec = Math.floor(ms / 1000);
  const min = Math.floor(totalSec / 60);
  const sec = totalSec % 60;
  return `${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
}

// Format date nicely
function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  return d.toLocaleDateString('ur-PK', { day: '2-digit', month: 'short', year: 'numeric' });
}

// Get today's date string YYYY-MM-DD
function todayStr() {
  return new Date().toISOString().split('T')[0];
}
