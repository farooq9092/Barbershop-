// ============================================
// app.js — Main Application Logic
// ============================================

let slotCheckResult = null;

/**
 * Initialize the app
 */
function init() {
  // Set today's date as default
  const dateInput = document.getElementById('apptDate');
  dateInput.value = todayStr();
  dateInput.min = todayStr();

  // Set default time to now + 30 min
  const now = new Date();
  now.setMinutes(now.getMinutes() + 30);
  const hh = String(now.getHours()).padStart(2, '0');
  const mm = String(now.getMinutes()).padStart(2, '0');
  document.getElementById('apptTime').value = `${hh}:${mm}`;

  // Render everything
  renderBarbers();
  renderAppointments();

  // Start tickers
  setInterval(tick, 1000);
  setInterval(fullRefresh, 15000); // Every 15s do full refresh
}

/**
 * Every-second tick (lightweight)
 */
function tick() {
  updateClock();
  updateTimers();
  updateApptCountdowns();
}

/**
 * Full refresh (every 15s)
 */
function fullRefresh() {
  const changed = syncAppointmentStatuses();
  if (changed) {
    renderBarbers();
    renderAppointments();
  }
}

/**
 * Check if selected slot is available
 */
function checkSlot() {
  const name = document.getElementById('clientName').value.trim();
  const phone = document.getElementById('clientPhone').value.trim();
  const barberId = parseInt(document.getElementById('barberSelect').value);
  const service = document.getElementById('serviceSelect').value;
  const date = document.getElementById('apptDate').value;
  const time = document.getElementById('apptTime').value;

  if (!barberId || !service || !date || !time) {
    showToast('Pehle barber, service, date aur time chunein!', 'error');
    return;
  }

  const result = checkSlotAvailability(barberId, date, time, service);
  slotCheckResult = result;

  const indicator = document.getElementById('slotIndicator');
  const status = document.getElementById('slotStatus');
  const bookBtn = document.getElementById('bookBtn');

  indicator.style.display = 'block';

  if (result.available) {
    indicator.className = 'slot-indicator available-slot';
    const svc = SERVICES[service];
    const queuePos = getQueuePosition(barberId, date, time);
    const barber = BARBERS.find(b => b.id === barberId);
    status.innerHTML = `
      ✅ <strong>Slot Available!</strong><br>
      Barber: <strong>${barber.name}</strong><br>
      Time: <strong>${time}</strong> → Ends at <strong>${result.estimatedEnd}</strong><br>
      Duration: <strong>${svc.duration} minutes</strong><br>
      ${queuePos > 0 ? `Queue position: <strong>#${queuePos + 1}</strong><br>` : ''}
      ${result.nextFree ? `Next available slot: <strong>${result.nextFree}</strong>` : ''}
    `;
    bookBtn.disabled = false;

    if (!name || !phone) {
      bookBtn.disabled = true;
      status.innerHTML += '<br><span style="color:var(--orange)">⚠ Naam aur WhatsApp number bhi bharein.</span>';
    }
  } else {
    indicator.className = 'slot-indicator busy-slot';
    status.innerHTML = `❌ <strong>Slot Busy!</strong><br>${result.reason}`;
    bookBtn.disabled = true;
  }
}

/**
 * Book appointment
 */
function bookAppointment() {
  const name = document.getElementById('clientName').value.trim();
  const phone = document.getElementById('clientPhone').value.trim();
  const barberId = parseInt(document.getElementById('barberSelect').value);
  const serviceKey = document.getElementById('serviceSelect').value;
  const date = document.getElementById('apptDate').value;
  const time = document.getElementById('apptTime').value;

  if (!name || !phone || !barberId || !serviceKey || !date || !time) {
    showToast('Sab fields bharna zaroori hai!', 'error');
    return;
  }

  // Re-verify slot one more time
  const check = checkSlotAvailability(barberId, date, time, serviceKey);
  if (!check.available) {
    showToast('Slot ab available nahi! Check karain.', 'error');
    slotCheckResult = null;
    checkSlot();
    return;
  }

  const service = SERVICES[serviceKey];
  const [h, m] = time.split(':').map(Number);

  const appt = {
    id: genId(),
    clientName: name,
    clientPhone: phone,
    barberId,
    service: serviceKey,
    date,
    time,
    timeMinutes: h * 60 + m,
    duration: service.duration,
    price: service.price,
    status: 'upcoming',
    bookedAt: new Date().toISOString(),
  };

  appointments.push(appt);
  saveAppointments();

  // Sync status immediately if today
  if (date === todayStr()) syncAppointmentStatuses();

  renderBarbers();
  renderAppointments();

  showToast(`✅ Appointment book ho gayi — ${name}`, 'success');

  // Reset form
  document.getElementById('clientName').value = '';
  document.getElementById('clientPhone').value = '';
  document.getElementById('barberSelect').value = '';
  document.getElementById('slotIndicator').style.display = 'none';
  document.getElementById('bookBtn').disabled = true;
  slotCheckResult = null;

  // Open WhatsApp
  sendWhatsAppConfirmation(appt);
}

/**
 * Mark appointment as done
 */
function markApptDone(apptId) {
  const appt = appointments.find(a => a.id === apptId);
  if (!appt) return;
  appt.status = 'completed';
  const barber = BARBERS.find(b => b.id === appt.barberId);
  if (barber && barber.currentClient === appt.clientName) {
    completeService(appt.barberId);
  }
  saveAppointments();
  renderBarbers();
  renderAppointments();
  showToast('✓ Service mukammal!', 'success');
}

/**
 * Toggle barber break
 */
function toggleBreak(barberId) {
  const barber = BARBERS.find(b => b.id === barberId);
  if (!barber) return;
  if (barber.status === 'break') {
    barber.status = 'available';
    showToast(`${barber.name} wapas aa gaye ✅`, 'success');
  } else if (barber.status === 'available') {
    barber.status = 'break';
    showToast(`${barber.name} break pe hain ☕`, 'info');
  }
  renderBarbers();
}

/**
 * Mark barber's current client done from card
 */
function markDone(barberId) {
  const barber = BARBERS.find(b => b.id === barberId);
  if (!barber || barber.status !== 'busy') {
    showToast('Barber abhi busy nahi hai', 'info');
    return;
  }
  // Find their in-progress appointment
  const appt = appointments.find(a =>
    a.barberId === barberId &&
    a.status === 'in-progress'
  );
  if (appt) {
    appt.status = 'completed';
    saveAppointments();
  }
  completeService(barberId);
  renderBarbers();
  renderAppointments();
  showToast(`✓ ${barber.name} — Client done!`, 'success');
}

/**
 * Clear completed appointments
 */
function clearCompleted() {
  const before = appointments.length;
  appointments = appointments.filter(a =>
    a.status !== 'completed' || a.date !== todayStr()
  );
  const removed = before - appointments.length;
  saveAppointments();
  renderAppointments();
  if (removed > 0) showToast(`${removed} completed appointments clear kiye`, 'info');
}

// Start the app
init();
