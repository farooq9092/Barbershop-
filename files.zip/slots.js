// ============================================
// slots.js — Advanced Slot Management Logic
// ============================================

const SHOP_OPEN  = 9 * 60;  // 9:00 AM in minutes
const SHOP_CLOSE = 21 * 60; // 9:00 PM in minutes
const BREAK_BUFFER = 5;     // 5 min buffer between appointments

/**
 * Get all booked slots for a barber on a date
 */
function getBarberSlots(barberId, dateStr) {
  return appointments.filter(a =>
    a.barberId === barberId &&
    a.date === dateStr &&
    a.status !== 'cancelled' &&
    a.status !== 'completed'
  ).sort((a, b) => a.timeMinutes - b.timeMinutes);
}

/**
 * Check if a time slot is available for a barber
 * Returns { available, reason, nextFree }
 */
function checkSlotAvailability(barberId, dateStr, timeStr, serviceKey) {
  const service = SERVICES[serviceKey];
  if (!service) return { available: false, reason: 'Invalid service' };

  const [h, m] = timeStr.split(':').map(Number);
  const startMin = h * 60 + m;
  const endMin = startMin + service.duration + BREAK_BUFFER;

  // Shop hours check
  if (startMin < SHOP_OPEN) {
    return { available: false, reason: `Shop opens at 9:00 AM. Please choose a later time.` };
  }
  if (endMin > SHOP_CLOSE) {
    return { available: false, reason: `Service would end after 9:00 PM. Please choose an earlier slot.` };
  }

  // Get existing slots for this barber on this date
  const booked = getBarberSlots(barberId, dateStr);

  // Check conflicts
  for (const slot of booked) {
    const slotEnd = slot.timeMinutes + slot.duration + BREAK_BUFFER;
    const conflict = startMin < slotEnd && endMin > slot.timeMinutes;
    if (conflict) {
      const freeAt = minutesToTime(slotEnd - BREAK_BUFFER);
      return {
        available: false,
        reason: `This barber is busy from ${minutesToTime(slot.timeMinutes)} to ${minutesToTime(slot.timeMinutes + slot.duration)} (${slot.clientName}). Next free: ${freeAt}`
      };
    }
  }

  // Check barber current real-time status
  const barber = BARBERS.find(b => b.id === barberId);
  const isToday = dateStr === todayStr();
  if (isToday && barber && barber.status === 'break') {
    return {
      available: false,
      reason: `${barber.name} is currently on break. They will be back soon.`
    };
  }

  // Find next free slot info
  const nextFree = findNextFreeSlot(barberId, dateStr, serviceKey);

  return {
    available: true,
    reason: `✅ Slot available! ${barber.name} is free from ${timeStr} for ${service.duration} minutes.`,
    estimatedEnd: minutesToTime(endMin - BREAK_BUFFER),
    nextFree
  };
}

/**
 * Find the next available slot for a barber today
 */
function findNextFreeSlot(barberId, dateStr, serviceKey) {
  const service = SERVICES[serviceKey];
  const booked = getBarberSlots(barberId, dateStr);

  let checkMin = SHOP_OPEN;
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  if (dateStr === todayStr()) {
    checkMin = Math.max(SHOP_OPEN, nowMin + 1);
  }

  // Walk through the day and find a free gap
  const sortedSlots = [...booked].sort((a, b) => a.timeMinutes - b.timeMinutes);

  while (checkMin + service.duration + BREAK_BUFFER <= SHOP_CLOSE) {
    let conflict = false;
    for (const slot of sortedSlots) {
      const slotEnd = slot.timeMinutes + slot.duration + BREAK_BUFFER;
      if (checkMin < slotEnd && (checkMin + service.duration + BREAK_BUFFER) > slot.timeMinutes) {
        conflict = true;
        checkMin = slotEnd;
        break;
      }
    }
    if (!conflict) return minutesToTime(checkMin);
  }
  return null;
}

/**
 * Get how many clients are ahead in queue for a barber
 */
function getQueuePosition(barberId, dateStr, timeStr) {
  const [h, m] = timeStr.split(':').map(Number);
  const targetMin = h * 60 + m;
  const booked = getBarberSlots(barberId, dateStr);
  return booked.filter(s => s.timeMinutes < targetMin).length;
}

/**
 * Get estimated wait time for the next walk-in
 */
function getWalkInWait(barberId) {
  const barber = BARBERS.find(b => b.id === barberId);
  if (!barber) return 0;
  if (barber.status === 'available') return 0;

  const now = Date.now();
  if (barber.currentServiceEnd && barber.currentServiceEnd > now) {
    return Math.ceil((barber.currentServiceEnd - now) / 60000); // minutes
  }
  return 0;
}

/**
 * Convert minutes from midnight to HH:MM string
 */
function minutesToTime(totalMin) {
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

/**
 * Start a service for a barber (mark busy)
 */
function startService(barberId, clientName, durationMin) {
  const barber = BARBERS.find(b => b.id === barberId);
  if (!barber) return;
  barber.status = 'busy';
  barber.currentClient = clientName;
  barber.currentServiceEnd = Date.now() + durationMin * 60 * 1000;
}

/**
 * Complete a service for a barber
 */
function completeService(barberId) {
  const barber = BARBERS.find(b => b.id === barberId);
  if (!barber) return;
  barber.status = 'available';
  barber.currentClient = null;
  barber.currentServiceEnd = null;
  barber.totalDone++;
}

/**
 * Get all available barbers right now
 */
function getAvailableBarbers() {
  return BARBERS.filter(b => b.status === 'available');
}

/**
 * Get countdown MS to appointment
 */
function getCountdownToAppointment(appt) {
  const apptDate = new Date(`${appt.date}T${appt.time}:00`);
  return apptDate - Date.now();
}

/**
 * Auto-update appointment statuses
 */
function syncAppointmentStatuses() {
  const now = Date.now();
  let changed = false;

  appointments.forEach(appt => {
    if (appt.status === 'completed' || appt.status === 'cancelled') return;

    const apptStart = new Date(`${appt.date}T${appt.time}:00`).getTime();
    const apptEnd = apptStart + appt.duration * 60 * 1000;

    if (now >= apptEnd) {
      appt.status = 'completed';
      changed = true;
      // Free the barber if this was their current job
      const barber = BARBERS.find(b => b.id === appt.barberId);
      if (barber && barber.currentClient === appt.clientName) {
        completeService(appt.barberId);
      }
    } else if (now >= apptStart && now < apptEnd) {
      if (appt.status !== 'in-progress') {
        appt.status = 'in-progress';
        changed = true;
        startService(appt.barberId, appt.clientName, appt.duration);
      }
    } else if (now < apptStart) {
      const diffMin = (apptStart - now) / 60000;
      if (diffMin <= 15 && appt.status === 'upcoming') {
        appt.status = 'waiting'; // About to start
        changed = true;
      }
    }
  });

  if (changed) saveAppointments();
  return changed;
}
