// ============================================
// ui.js — UI Rendering & DOM Updates
// ============================================

/**
 * Render all barber cards
 */
function renderBarbers() {
  const grid = document.getElementById('barbersGrid');
  const select = document.getElementById('barberSelect');

  grid.innerHTML = '';
  select.innerHTML = '<option value="">-- Barber chunein --</option>';

  let availCount = 0, busyCount = 0;

  BARBERS.forEach(barber => {
    if (barber.status === 'available') availCount++;
    if (barber.status === 'busy') busyCount++;

    // Build card
    const card = document.createElement('div');
    card.className = `barber-card ${barber.status}`;
    card.id = `barber-card-${barber.id}`;

    // Timer info
    let timerHTML = '';
    if (barber.status === 'busy' && barber.currentServiceEnd) {
      const msLeft = barber.currentServiceEnd - Date.now();
      const pct = Math.max(0, Math.min(100, (msLeft / (30 * 60000)) * 100));
      timerHTML = `
        <div class="barber-timer">
          <div class="timer-bar-track">
            <div class="timer-bar-fill" id="bar-${barber.id}" style="width:${pct}%"></div>
          </div>
          <div class="timer-label">Free in: <span class="timer-countdown" id="timer-${barber.id}">${formatCountdown(msLeft)}</span></div>
        </div>`;
    } else if (barber.status === 'available') {
      timerHTML = `<div class="barber-timer">
        <div class="timer-bar-track">
          <div class="timer-bar-fill" style="width:100%"></div>
        </div>
        <div class="timer-label">Ready to serve</div>
      </div>`;
    } else {
      timerHTML = `<div class="barber-timer">
        <div class="timer-label" style="color:var(--orange)">On break — back soon</div>
      </div>`;
    }

    // Queue dots
    const queuedToday = getBarberSlots(barber.id, todayStr()).length;
    let dots = '';
    for (let i = 0; i < 5; i++) {
      dots += `<div class="queue-dot ${i < queuedToday ? 'filled' : ''}"></div>`;
    }

    // Status text
    let statusText = '';
    if (barber.status === 'available') statusText = '● Available';
    else if (barber.status === 'busy') statusText = `● Busy — ${barber.currentClient || 'Client'}`;
    else statusText = '● On Break';

    card.innerHTML = `
      <div class="barber-avatar">
        ${barber.emoji}
        <div class="barber-status-dot"></div>
      </div>
      <div class="barber-name">${barber.name}</div>
      <div class="barber-specialty">${barber.specialty}</div>
      <div class="barber-status-text">${statusText}</div>
      ${timerHTML}
      <div class="queue-count">
        <div class="queue-dots">${dots}</div>
        <span>${queuedToday} today</span>
      </div>
      <div class="barber-actions">
        <button class="btn-toggle" onclick="toggleBreak(${barber.id})">
          ${barber.status === 'break' ? '▶ Resume' : '☕ Break'}
        </button>
        <button class="btn-toggle" onclick="markDone(${barber.id})">✓ Done</button>
      </div>`;

    grid.appendChild(card);

    // Add to select if available or on break
    if (barber.status !== 'busy') {
      const opt = document.createElement('option');
      opt.value = barber.id;
      opt.textContent = `${barber.name} — ${barber.specialty}`;
      select.appendChild(opt);
    }
  });

  // Update stats
  document.getElementById('statAvailable').textContent = availCount;
  document.getElementById('statBusy').textContent = busyCount;
  document.getElementById('statQueued').textContent = appointments.filter(a =>
    a.date === todayStr() && a.status === 'upcoming').length;
  document.getElementById('statToday').textContent = appointments.filter(a =>
    a.date === todayStr()).length;
}

/**
 * Update timers only (lightweight, every second)
 */
function updateTimers() {
  BARBERS.forEach(barber => {
    if (barber.status === 'busy' && barber.currentServiceEnd) {
      const msLeft = barber.currentServiceEnd - Date.now();
      const timerEl = document.getElementById(`timer-${barber.id}`);
      const barEl = document.getElementById(`bar-${barber.id}`);
      if (timerEl) timerEl.textContent = formatCountdown(Math.max(0, msLeft));
      if (barEl) {
        // Estimate 30 min max service
        const pct = Math.max(0, Math.min(100, (msLeft / (30 * 60000)) * 100));
        barEl.style.width = pct + '%';
      }
    }
  });
}

/**
 * Render appointments list
 */
function renderAppointments() {
  const list = document.getElementById('appointmentsList');
  const today = appointments.filter(a => a.date === todayStr())
    .sort((a, b) => a.timeMinutes - b.timeMinutes);

  if (!today.length) {
    list.innerHTML = `<div class="empty-state">
      <span class="empty-icon">📋</span>
      <p>Aaj koi appointment nahi</p>
    </div>`;
    return;
  }

  list.innerHTML = '';
  today.forEach(appt => {
    const barber = BARBERS.find(b => b.id === appt.barberId);
    const service = SERVICES[appt.service];
    const card = buildApptCard(appt, barber, service);
    list.appendChild(card);
  });
}

function buildApptCard(appt, barber, service) {
  const card = document.createElement('div');
  card.className = `appt-card status-${appt.status}`;
  card.id = `appt-${appt.id}`;

  const msLeft = getCountdownToAppointment(appt);
  const minsLeft = Math.floor(msLeft / 60000);

  let countdownHTML = '';
  if (appt.status === 'upcoming' || appt.status === 'waiting') {
    countdownHTML = `<div class="appt-countdown">
      <span class="countdown-value" id="cd-${appt.id}">${minsLeft > 0 ? minsLeft + 'm' : 'Now!'}</span>
      <span class="countdown-label">baqi</span>
    </div>`;
  } else if (appt.status === 'in-progress') {
    const apptStart = new Date(`${appt.date}T${appt.time}:00`).getTime();
    const msElapsed = Date.now() - apptStart;
    const minsElapsed = Math.floor(msElapsed / 60000);
    countdownHTML = `<div class="appt-countdown">
      <span class="countdown-value" style="color:var(--green)">${minsElapsed}m</span>
      <span class="countdown-label">chal raha</span>
    </div>`;
  } else {
    countdownHTML = `<div class="appt-countdown">
      <span class="countdown-value" style="color:var(--text-muted)">✓</span>
      <span class="countdown-label">mukammal</span>
    </div>`;
  }

  // Badge
  const badges = {
    upcoming: 'badge-upcoming',
    waiting: 'badge-waiting',
    'in-progress': 'badge-in-progress',
    completed: 'badge-completed',
  };
  const badgeLabels = {
    upcoming: 'Upcoming',
    waiting: '15 min mein!',
    'in-progress': 'Chal raha hai',
    completed: 'Mukammal',
  };

  card.innerHTML = `
    <div class="appt-info">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
        <div class="appt-name">${appt.clientName}</div>
        <span class="status-badge ${badges[appt.status] || ''}">
          ${badgeLabels[appt.status] || appt.status}
        </span>
      </div>
      <div class="appt-meta">
        <span>✂ ${service?.label || appt.service}</span>
        <span>⏰ ${appt.time}</span>
        <span>💈 ${barber?.name || 'N/A'}</span>
        <span>📱 ${appt.clientPhone}</span>
      </div>
    </div>
    ${countdownHTML}
    <div class="appt-actions">
      <button class="btn-icon" onclick="sendWhatsAppReminder('${appt.id}')">📱 Remind</button>
      ${appt.status !== 'completed' ? `<button class="btn-icon btn-done" onclick="markApptDone('${appt.id}')">✓ Done</button>` : ''}
    </div>`;

  return card;
}

/**
 * Update countdown timers in appointment cards
 */
function updateApptCountdowns() {
  const today = appointments.filter(a => a.date === todayStr());
  today.forEach(appt => {
    const cdEl = document.getElementById(`cd-${appt.id}`);
    if (!cdEl) return;
    if (appt.status !== 'upcoming' && appt.status !== 'waiting') return;
    const msLeft = getCountdownToAppointment(appt);
    const minsLeft = Math.floor(msLeft / 60000);
    cdEl.textContent = minsLeft > 0 ? minsLeft + 'm' : 'Abhi!';
    if (minsLeft <= 5) cdEl.style.color = 'var(--red)';
    else if (minsLeft <= 15) cdEl.style.color = 'var(--orange)';
    else cdEl.style.color = 'var(--gold)';
  });
}

/**
 * Show toast notification
 */
function showToast(msg, type = 'info') {
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3500);
}

/**
 * Update live clock
 */
function updateClock() {
  const now = new Date();
  const h = String(now.getHours()).padStart(2, '0');
  const m = String(now.getMinutes()).padStart(2, '0');
  const s = String(now.getSeconds()).padStart(2, '0');
  const el = document.getElementById('liveClock');
  if (el) el.textContent = `${h}:${m}:${s}`;
}
