# ✂️ Royal Cut — Professional Barbershop Management System

A **world-class barbershop appointment & slot management system** built with pure HTML, CSS, and JavaScript. No frameworks, no backend needed — runs completely in the browser.

---

## 🚀 Features

### Real-Time Slot Management
- **4 barber seats** with live status (Available / Busy / Break)
- **Conflict detection** — no double bookings ever
- **Buffer time** between appointments (5 min)
- **Smart queue** — shows who's next, how many clients ahead
- **Auto-status sync** — appointments auto-update to In-Progress / Completed

### Live Countdown Timers
- Per-barber countdown: "Free in X:XX"
- Progress bar showing service completion
- Per-appointment countdown: "X minutes baqi"
- Color-coded urgency (green → orange → red)

### WhatsApp Integration 📱
- **Booking confirmation** sent automatically on booking
- **Reminder messages** with one click — shows time remaining
- **Pre-built Urdu messages** — professional barbershop tone
- Direct WhatsApp links with pre-filled messages

### Appointment Management
- Book for today or future dates
- View all today's appointments sorted by time
- Status badges: Upcoming / 15 min mein! / Chal raha hai / Mukammal
- One-click "Done" per appointment or per barber seat
- Clear completed appointments

---

## 📁 File Structure

```
barbershop/
├── index.html          # Main HTML file
├── css/
│   └── style.css       # All styles (dark luxury theme)
├── js/
│   ├── data.js         # Barber & service data, helpers
│   ├── slots.js        # Slot logic, conflict detection, timers
│   ├── whatsapp.js     # WhatsApp message builder & sender
│   ├── ui.js           # DOM rendering functions
│   └── app.js          # Main app logic & event handlers
└── README.md
```

---

## 🛠 Setup

1. **Clone the repo:**
   ```bash
   git clone https://github.com/yourusername/barbershop.git
   cd barbershop
   ```

2. **Open in browser:**
   ```bash
   # Just open index.html — no server needed!
   open index.html
   ```

3. **Or serve locally:**
   ```bash
   npx serve .
   # Visit http://localhost:3000
   ```

---

## ✏️ Customization

### Change Barber Names
Edit `js/data.js` → `BARBERS` array:
```js
{ id: 1, name: "Aap ka naam", emoji: "💈", specialty: "Your specialty" }
```

### Change Services & Prices
Edit `js/data.js` → `SERVICES` object:
```js
haircut: { label: "Haircut", duration: 20, price: 200 }
```

### Change Shop Hours
Edit `js/slots.js`:
```js
const SHOP_OPEN  = 9 * 60;   // 9:00 AM
const SHOP_CLOSE = 21 * 60;  // 9:00 PM
```

### WhatsApp Phone Format
When booking, enter number as: `+923001234567` or `03001234567`

---

## 📱 WhatsApp Messages

All messages are in **Urdu/Roman Urdu** — professional barbershop tone.

**Booking Confirmation includes:**
- Client name, date, time
- Barber name & seat number
- Service & price
- Time remaining until appointment

**Reminder Message includes:**
- Minutes remaining
- Urgency indicator (changes at 30/15/5 minutes)
- Warning if less than 10 minutes

---

## 💾 Data Storage

All data is saved in **localStorage** — persists across browser refreshes.
No server or database needed.

---

## 🎨 Design

- **Theme:** Dark luxury (black + gold)
- **Fonts:** Playfair Display + DM Sans
- **Mobile:** Fully responsive (2-col on tablet, 1-col on mobile)

---

## 📄 License

MIT — Free to use and modify.

---

*Built for Pakistani barbershops — Look Sharp, Feel Sharp* 👑
