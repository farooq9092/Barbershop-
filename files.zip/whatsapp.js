// ============================================
// whatsapp.js — WhatsApp Messaging Integration
// ============================================

let currentWALink = '';
let currentReminderLink = '';

/**
 * Build WhatsApp confirmation message for new booking
 */
function buildConfirmationMsg(appt, barber, service) {
  const timeLeft = getCountdownToAppointment(appt);
  const hoursLeft = Math.floor(timeLeft / 3600000);
  const minsLeft = Math.floor((timeLeft % 3600000) / 60000);
  const timeLeftStr = hoursLeft > 0 ? `${hoursLeft} ghante ${minsLeft} minute` : `${minsLeft} minute`;

  return `✂️ *Royal Cut Barbershop*
━━━━━━━━━━━━━━━━━━━

Assalam o Alaikum *${appt.clientName}* bhai! 🙏

Aap ki appointment confirm ho gayi hai!

📅 *Date:* ${formatDate(appt.date)}
⏰ *Time:* ${appt.time}
💈 *Barber:* ${barber.name}
✂️ *Service:* ${service.label}
⏱ *Duration:* ${service.duration} minutes
💰 *Price:* Rs. ${service.price}
🪑 *Seat:* #${barber.id}

━━━━━━━━━━━━━━━━━━━
⏳ *Aane mein baqi:* ${timeLeftStr}

📍 Hum aap ka intezaar kar rahe hain!
Kisi bhi sawaal ke liye message karen.

_Royal Cut — Look Sharp, Feel Sharp_ 👑`;
}

/**
 * Build reminder message (sent before appointment)
 */
function buildReminderMsg(appt, barber, service, minsRemaining) {
  let urgency = '';
  if (minsRemaining <= 5) urgency = '🚨 *Abhi chalen!*';
  else if (minsRemaining <= 15) urgency = '⚡ *Jaldi chalen!*';
  else if (minsRemaining <= 30) urgency = '⏰ *Taiyar ho jain!*';
  else urgency = '📢 *Yaad dihaani*';

  return `${urgency}

✂️ *Royal Cut Barbershop*
━━━━━━━━━━━━━━━━━━━

Salam *${appt.clientName}* bhai!

Aap ki appointment mein sirf
🕐 *${minsRemaining} minute* baqi hain!

💈 Barber: *${barber.name}*
✂️ Service: *${service.label}*
⏰ Time: *${appt.time}*

${minsRemaining <= 10 ? '⚠️ Please jaldi aayen — slot miss hone ki soorat mein appointment cancel ho sakti hai.' : ''}

Hum aap ka intezaar kar rahe hain! 🙏
_Royal Cut Team_`;
}

/**
 * Build cancellation message
 */
function buildCancellationMsg(appt, barber, service) {
  return `❌ *Appointment Cancelled*

✂️ *Royal Cut Barbershop*
━━━━━━━━━━━━━━━━━━━

Salam *${appt.clientName}* bhai,

Aap ki appointment cancel ho gayi hai.

📅 Date: ${formatDate(appt.date)}
⏰ Time: ${appt.time}
💈 Barber: ${barber.name}

Dobara booking ke liye humse rabta karen.
Shukriya! 🙏

_Royal Cut Team_`;
}

/**
 * Open WhatsApp with appointment confirmation
 */
function sendWhatsAppConfirmation(appt) {
  const barber = BARBERS.find(b => b.id === appt.barberId);
  const service = SERVICES[appt.service];
  if (!barber || !service) return;

  const msg = buildConfirmationMsg(appt, barber, service);
  const phone = appt.clientPhone.replace(/[^0-9]/g, '');
  const encodedMsg = encodeURIComponent(msg);
  currentWALink = `https://wa.me/${phone}?text=${encodedMsg}`;

  document.getElementById('waPreview').textContent = msg;
  document.getElementById('waModal').style.display = 'flex';
}

/**
 * Send reminder for appointment
 */
function sendWhatsAppReminder(apptId) {
  const appt = appointments.find(a => a.id === apptId);
  if (!appt) return;

  const barber = BARBERS.find(b => b.id === appt.barberId);
  const service = SERVICES[appt.service];
  if (!barber || !service) return;

  const msLeft = getCountdownToAppointment(appt);
  const minsLeft = Math.max(1, Math.round(msLeft / 60000));

  const msg = buildReminderMsg(appt, barber, service, minsLeft);
  const phone = appt.clientPhone.replace(/[^0-9]/g, '');
  const encodedMsg = encodeURIComponent(msg);
  currentReminderLink = `https://wa.me/${phone}?text=${encodedMsg}`;

  document.getElementById('reminderPreview').textContent = msg;
  document.getElementById('reminderModal').style.display = 'flex';
}

function openWhatsApp() {
  if (currentWALink) window.open(currentWALink, '_blank');
  closeModal();
}

function openReminderWA() {
  if (currentReminderLink) window.open(currentReminderLink, '_blank');
  closeReminderModal();
}

function closeModal() {
  document.getElementById('waModal').style.display = 'none';
}

function closeReminderModal() {
  document.getElementById('reminderModal').style.display = 'none';
}
